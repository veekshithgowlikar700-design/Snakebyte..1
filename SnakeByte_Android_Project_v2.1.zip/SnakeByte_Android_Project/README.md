# SnakeByte 🐍

SnakeByte is a Python learning Android app built as a WebView project.

## Changes in this version
- Renamed the app to **SnakeByte**.
- Added a clean first-launch name/login screen.
- Fixed small-screen header/text crowding and login layout overlap.
- Added light/dark mode with the choice saved on the device.
- Added automatic progression: after completing a lesson/coding mission, SnakeByte opens the next lesson automatically.
- Course/world progression remains locked until the previous lesson/world is completed.
- Preserves existing progress stored in `localStorage`.
- Added a GitHub Actions workflow that builds a debug APK automatically.

## Latest fixes
- Coding missions now start with an **empty editor** — the learner types the code (with a quick-symbol bar for `( ) [ ] { } ' " : = #` and Tab).
- Each mission shows the **goal output**; Hint shows a tip, and a second tap reveals an example answer.
- Fixed **even-numbered levels being skipped**: those levels have coding missions, and "Got it" used to auto-advance past them. Now they only complete when the code is typed correctly.
- Fixed the "Level N complete" message showing the wrong number.
- Python engine no longer gets stuck after a failed load; curly quotes from phone keyboards are handled.
- New original snake app icon (adaptive, round, themed/monochrome, and legacy PNGs).

## Build the APK through GitHub

1. Create a new GitHub repository.
2. Upload the contents of this `SnakeByte_Android_Project` folder to the repository root.
3. Open **Actions** → **Build SnakeByte APK**.
4. Run it with **Run workflow**, or push to `main`/`master`.
5. After the workflow finishes, open the run and download the **SnakeByte-debug-apk** artifact.
6. Extract the artifact and install `app-debug.apk` on Android.

### Local Android Studio build
Open the project root in Android Studio and run:
`gradle assembleDebug`

The APK will be at:
`app/build/outputs/apk/debug/app-debug.apk`

The Python runner still loads Pyodide from the internet, so coding execution requires internet access.
